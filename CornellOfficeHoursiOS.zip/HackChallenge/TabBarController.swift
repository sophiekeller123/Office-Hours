//
//  TabBarController.swift
//  HackChallenge
//
//  Created by Sophie Keller on 11/18/19.
//  Copyright © 2019 Sophie Keller. All rights reserved.
//

import UIKit

class TabBarController: UITabBarController {
    var data: User!
    
    init(data: User) {
        self.data = data
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    override func viewDidLoad() {

        super.viewDidLoad()
        
        title = "My Office Hours"
        view.backgroundColor = .lightGray
        
        tabBar.barTintColor = UIColor(red: 77/255.0,green: 128/255.0, blue: 228/255.0, alpha: 1.0)
        
        
        navigationController?.isToolbarHidden = false
        navigationController?.navigationBar.barTintColor = UIColor(red: 77/255.0,green: 128/255.0, blue: 228/255.0, alpha: 1.0)
        navigationController?.navigationBar.titleTextAttributes = [.font: UIFont.boldSystemFont(ofSize: 25.0)]
        
        let addViewController = AddClassViewController()
        addViewController.user = self.data
        addViewController.tabBarItem = UITabBarItem(title: "Add", image: nil, tag: 0)
        
        let calendarViewController = TodayViewController()
        calendarViewController.user = self.data
        calendarViewController.tabBarItem = UITabBarItem(title: "Today's Hours", image: nil, tag: 1)
        
        let profileViewController = ClassesViewController()
        profileViewController.user = self.data
        profileViewController.tabBarItem = UITabBarItem(title: "My Classes", image: nil, tag: 2)
        
        UITabBarItem.appearance().setTitleTextAttributes([.font: UIFont.boldSystemFont(ofSize: 20.0), .foregroundColor: UIColor.white], for: .normal)
    
        let viewControllerList = [addViewController, calendarViewController, profileViewController]
        
        viewControllers = viewControllerList
        
    }
    

}
