//
//  ClassesViewController.swift
//  HackChallenge
//
//  Created by Sophie Keller on 11/18/19.
//  Copyright © 2019 Sophie Keller. All rights reserved.
//

import UIKit

class ClassesViewController: UIViewController {
    var classesView: UICollectionView!
    var classes: [Course] = []
    var padding: CGFloat = 8
    var user: User!
    var errorLabel: UILabel!
    
    let classCellReuseIdentifier = "classcellreuseidentifier"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "My Classes"
        view.backgroundColor = .white
        
        errorLabel?.text = ""
        
        let layout = UICollectionViewFlowLayout()
        layout.scrollDirection = .vertical
        layout.minimumLineSpacing = padding
        layout.minimumInteritemSpacing = padding
        
        classesView = UICollectionView(frame: .zero, collectionViewLayout: layout)
        classesView.translatesAutoresizingMaskIntoConstraints = false
        classesView.backgroundColor = .white
        classesView.register(ClassCollectionViewCell.self, forCellWithReuseIdentifier: classCellReuseIdentifier)
        
        classesView.dataSource = self
        classesView.delegate = self
        
        errorLabel = UILabel()
        errorLabel.textColor = UIColor(red: 77/255.0,green: 128/255.0, blue: 228/255.0, alpha: 1.0)
        errorLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(errorLabel)
        
        if self.classes.isEmpty{
                errorLabel.text = "Select Class"
        }
        
        view.addSubview(classesView)
        
        setupConstraints()
        
    }
    func setupConstraints() {
        NSLayoutConstraint.activate([
            errorLabel.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 5*padding),
            errorLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
               ])
        NSLayoutConstraint.activate([
            classesView.topAnchor.constraint(equalTo: errorLabel.bottomAnchor, constant: padding),
            classesView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 2*padding),
            classesView.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: -padding),
            classesView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -2*padding)
        ])
    }
    override func viewWillAppear(_ animated: Bool) {
        errorLabel.text = ""
        self.tabBarController?.navigationItem.title = "My Classes"
        self.tabBarController?.navigationController?.navigationBar.barTintColor = UIColor(red: 77/255.0,green: 128/255.0, blue: 228/255.0, alpha: 1.0)

        navigationController?.navigationBar.titleTextAttributes = [.foregroundColor: UIColor.white, .font: UIFont.boldSystemFont(ofSize: 25.0)]

           NetworkManager.getCourses(fromId: self.user.id) { (data) in
               self.user = data
            self.classes = data.courses
            self.classesView.reloadData()
                   }
            if !self.classes.isEmpty{
                errorLabel.text = "Select Class"
        
           }
       
    }}

extension ClassesViewController: UICollectionViewDataSource {

func numberOfSections(in collectionView: UICollectionView) -> Int {
    return 1
}

func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
    return classes.count
}


func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
    let cell = collectionView.dequeueReusableCell(withReuseIdentifier: classCellReuseIdentifier, for: indexPath) as! ClassCollectionViewCell
        cell.configure(for: classes[indexPath.row])
    return cell
    }

}
extension ClassesViewController: UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        // We want: | padding CELL padding CELL padding CELL padding |
        return CGSize(width: collectionView.frame.width, height: 60)
    }
    
}
extension ClassesViewController: UICollectionViewDelegate {

func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
    let viewController = ClassWeekViewController()
    viewController.selectedclass = classes[indexPath.row]

    navigationController?.pushViewController(viewController, animated: true)
    
    }
    

}



    
    

 
