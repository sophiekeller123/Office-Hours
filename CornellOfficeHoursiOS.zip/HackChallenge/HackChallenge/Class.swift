//
//  Class.swift
//  HackChallenge
//
//  Created by Sophie Keller on 11/18/19.
//  Copyright © 2019 Sophie Keller. All rights reserved.
//

import Foundation

class Class: Codable {
    var title: String!
    var instructor: String!
    var color: [Double]!
    var classs: String!
    
    init(classs: String!, title: String, instructor: String){
        self.classs = classs
        self.title = title
        self.instructor = instructor
        self.color = [drand48(), drand48(), drand48()]
        
    }

}
struct Response: Codable{
    var data: User
}
struct Response1: Codable{
    var data: [Course]
}

class Data: Codable{
    var id: Int
    var code: String
    var name: String
    var instructors: [String]
}

class User: Codable{
    var id: Int
    var name: String
    var username: String
    var courses: [Course]
}

class Course: Codable{
    var id: Int
    var code: String
    var name: String
    var instructors: [Instructor]
}

class Instructor: Codable{
    var id: Int
    var name: String
    var netid: String
    var officehours: [OffHour]
}

class OffHour: Codable{
    var id: Int
    var place: String
    var room: Int
    var day: String
    var time: [Time]
    
}

class Time: Codable{
    var start_hours: Int
    var start_minutes: Int
    var end_hours: Int
    var end_minutes: Int
    
}
