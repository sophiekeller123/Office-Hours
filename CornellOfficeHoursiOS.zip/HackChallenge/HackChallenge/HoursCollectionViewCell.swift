//
//  HoursCollectionViewCell.swift
//  HackChallenge
//
//  Created by Sophie Keller on 11/18/19.
//  Copyright © 2019 Sophie Keller. All rights reserved.
//

import UIKit

class HoursCollectionViewCell: UICollectionViewCell {
    var classLabel: UILabel!
    var timeLabel: UILabel!
    var colors: [UIColor]!
    var dictionary: [String: UIColor] = [:]
    var count: Int = 0
    
        override init(frame: CGRect) {
            super.init(frame: frame)
            
            backgroundColor = UIColor(red: 128.0/255.0, green: 171.0/255.0, blue: 209.0/255.0, alpha: 1.0)
            
            colors = [UIColor(red:77/255.0, green:141/255.0, blue:228/255.0, alpha:1.0),UIColor(red:77/255.0, green:228/255.0, blue:164/255.0, alpha:1.0),UIColor(red:228/255.0, green:77/255.0, blue:141/255.0, alpha:1.0),UIColor(red:228/255.0, green:164/255.0, blue:77/255.0, alpha:1.0),UIColor(red:228/255.0, green:88/255.0, blue:77/255.0, alpha:1.0),UIColor(red:77/255.0, green:128/255.0, blue:228/255.0, alpha:1.0)]
            
            classLabel = UILabel()
            classLabel.translatesAutoresizingMaskIntoConstraints = false
            classLabel.textAlignment = .left
            classLabel.clipsToBounds = true
            classLabel.font = UIFont.systemFont(ofSize: 20)
            classLabel.font = UIFont.boldSystemFont(ofSize: 16.0)
            classLabel.backgroundColor = UIColor(red: 128.0/255.0, green: 171.0/255.0, blue: 209.0/255.0, alpha: 1.0)
            classLabel.textColor = .white
            addSubview(classLabel)
            
            timeLabel = UILabel()
            timeLabel.translatesAutoresizingMaskIntoConstraints = false
            timeLabel.textAlignment = .left
            timeLabel.clipsToBounds = true
            timeLabel.font = UIFont.systemFont(ofSize: 12)
            timeLabel.backgroundColor = UIColor(red: 128.0/255.0, green: 171.0/255.0, blue: 209.0/255.0, alpha: 1.0)
            timeLabel.textColor = .white
            addSubview(timeLabel)
            
            
            setupConstraints()
        }

        func setupConstraints() {
            NSLayoutConstraint.activate([
                classLabel.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 8),
                classLabel.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 15),
                classLabel.trailingAnchor.constraint(equalTo: contentView.trailingAnchor),
                classLabel.heightAnchor.constraint(equalToConstant: 26)
            ])
            NSLayoutConstraint.activate([
                timeLabel.topAnchor.constraint(equalTo: classLabel.bottomAnchor, constant: 3),
                timeLabel.leadingAnchor.constraint(equalTo: classLabel.leadingAnchor),
                timeLabel.trailingAnchor.constraint(equalTo: contentView.trailingAnchor),
                
            ])
            
        }
        
        func configure(for event: Event) {
            classLabel.text = event.classs
            let time = formattime(event: event)
            timeLabel.text = time + " with " + event.ta
            let color = colors?[Int(arc4random_uniform(_:5))]
            classLabel.backgroundColor = color
            timeLabel.backgroundColor = color
            timeLabel.backgroundColor = color
            backgroundColor = color
            
            
    }
    
    func formattime(event: Event)->String{
        var hour1 = event.starttime[0]
        var hour2 = event.endtime[0]
        var sign1 = "a.m."
        var sign2 = "a.m."
        let min1 = event.starttime[1]
        let min2 = event.endtime[1]
        if hour1==12{
            sign1 = "p.m."
        }
        if hour2 == 12{
            sign2 = "p.m."
        }
        if hour1==0{
            hour1 = 12
        }
        if hour2==0{
            hour2 = 12
        }
        if hour1>12{
            hour1 = hour1-12
            sign1 = "p.m."
        }
        if hour2>12{
            hour2 = hour2 - 12
            sign2 = "p.m."
        }
        var min11 = String(min1)
        if min1<10{
            min11 = "0" + String(min1)
        }
        var min22 = String(min2)
        if min2<10{
            min22 = "0" + String(min2)
        }
        return "\(hour1):\(min11) \(sign1) - \(hour2):\(min22) \(sign2)"
           
        
    }
        required init?(coder: NSCoder) {
            fatalError("init(coder:) has not been implemented")
        }
    }

