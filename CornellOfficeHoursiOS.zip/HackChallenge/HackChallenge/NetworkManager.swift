//
//  NetworkManager.swift
//  HackChallenge
//
//  Created by Sophie Keller on 12/2/19.
//  Copyright © 2019 Sophie Keller. All rights reserved.
//

import Foundation
import Alamofire
import SwiftyJSON

class NetworkManager {
    
    private static let makeacctURL = "http://35.237.235.192/api/users/"
    private static let loginURL = "http://35.237.235.192/api/user/"
    private static let addURL = "http://35.237.235.192/api/user/1/courses/"
    private static let getcoursesURL = "http://35.237.235.192/api/user/1/courses/"
    
    static func makeacct(fromUser userdict: [String: Any], _ didPostInfo: @escaping (User) -> Void) {
        Alamofire.request(makeacctURL, method: .post, parameters: userdict, encoding: JSONEncoding.default).validate(statusCode: 200..<500).responseData { response in switch response.result {
            case .success(let data):
                let jsonDecoder = JSONDecoder()
                if let userData = try? jsonDecoder.decode(Response.self, from : data){
                    let user = userData.data
                    UserDefaults.standard.set(user.id, forKey: "user_key")
                    didPostInfo(user)
                }
            case .failure(let error):
                print(error.localizedDescription)
            }
    }
      
    }
    static func login(fromUser userdict: [String: String], _ didPostInfo: @escaping (User) -> Void) {
        Alamofire.request(loginURL, method: .post, parameters: userdict, encoding: URLEncoding.default).validate(statusCode: 200..<500).responseData { response in switch response.result {
            case .success(let data):
                let jsonDecoder = JSONDecoder()
                if let userData = try? jsonDecoder.decode(User.self, from : data){
                    let user = userData
                    didPostInfo(user)
            }
        case .failure(let error):
            print(error.localizedDescription)
            }
    }
      
    }
    static func getCourses(fromId id: Int, _ didGetUser: @escaping (User) -> Void) {
        let url = "http://35.237.235.192/api/user/\(id)/"
        Alamofire.request(url, method: .get, encoding: URLEncoding.default).validate(statusCode: 200..<500).responseData { response in switch response.result {
            case .success(let data):
                let jsonDecoder = JSONDecoder()
                if let userData = try? jsonDecoder.decode(Response.self, from: data){
                    let user = userData.data
                    didGetUser(user)
            }
            case .failure(let error):
            print(error.localizedDescription)
            }
        }
    }
    
    static func addClass(fromId id: Int, fromUserID id2: Int, _ didPostInfo: @escaping (User) -> Void) {
        let url = "http://35.237.235.192/api/user/\(id2)/courses/"
        let dict = ["course_id": id]
        Alamofire.request(url, method: .post, parameters: dict, encoding: JSONEncoding.default).validate(statusCode: 200..<500).responseData { response in
            switch response.result {
            case .success(let data):
                let jsonDecoder = JSONDecoder()
                if let userData = try? jsonDecoder.decode(Response.self, from : data){
                    let userdata = userData.data
                    didPostInfo(userdata)
                }
        
            case .failure(let error):
                print(error.localizedDescription)
            }
            }
    }
    
    static func getCoursefromCode(fromCode code: String, _ didPostInfo: @escaping (Int, Bool) -> Void) {
        let url = "http://35.237.235.192/api/course/"+code+"/"
           Alamofire.request(url, method: .get, encoding: JSONEncoding.default).validate(statusCode: 200..<500).responseData { response in
            switch response.result {
               case .success(let data):
                    let jsonDecoder = JSONDecoder()
                    guard let userData = try? jsonDecoder.decode(Response1.self, from : data) else {
                        return didPostInfo(0, false) }
                        let id = userData.data[0].id
                        didPostInfo(id, true)
            case .failure(let error):
                print(error.localizedDescription)
            }
                
       }
    }
}

    
