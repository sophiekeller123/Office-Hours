//
//  ClassCollectionViewCell.swift
//  HackChallenge
//
//  Created by Sophie Keller on 11/18/19.
//  Copyright © 2019 Sophie Keller. All rights reserved.
//

import UIKit

class ClassCollectionViewCell: UICollectionViewCell {
    var color: UIColor!
    var codeLabel: UILabel!
    var titleLabel: UILabel!
    var dotLabel: UILabel!
    var instructorLabel: UILabel!
    var colors: [UIColor] = []
    var count: Int = 1
    var dictionary: [String: UIColor] = [:]


    override init(frame: CGRect) {
        super.init(frame: frame)
        
        color = UIColor(red: 128.0/255.0, green: 171.0/255.0, blue: 209.0/255.0, alpha: 1.0)

        colors = [UIColor(red:77/255.0, green:141/255.0, blue:228/255.0, alpha:1.0),UIColor(red:77/255.0, green:228/255.0, blue:164/255.0, alpha:1.0),UIColor(red:228/255.0, green:77/255.0, blue:141/255.0, alpha:1.0),UIColor(red:228/255.0, green:164/255.0, blue:77/255.0, alpha:1.0),UIColor(red:228/255.0, green:88/255.0, blue:77/255.0, alpha:1.0),UIColor(red:77/255.0, green:128/255.0, blue:228/255.0, alpha:1.0)]
        
        
        self.backgroundColor = color
        
        codeLabel = UILabel()
        codeLabel.translatesAutoresizingMaskIntoConstraints = false
        codeLabel.textAlignment = .left
        codeLabel.font = UIFont.systemFont(ofSize: 20)
        codeLabel.font = UIFont.boldSystemFont(ofSize: 16.0)
        codeLabel.textColor = UIColor.white
        codeLabel.backgroundColor = color
        contentView.addSubview(codeLabel)
        
        titleLabel = UILabel()
        titleLabel.translatesAutoresizingMaskIntoConstraints = false
        titleLabel.textAlignment = .left
        titleLabel.font = UIFont.systemFont(ofSize: 12)
        titleLabel.textColor = UIColor.white
        titleLabel.backgroundColor = color
        contentView.addSubview(titleLabel)
        
        dotLabel = UILabel()
        dotLabel.translatesAutoresizingMaskIntoConstraints = false
        dotLabel.textAlignment = .center
        dotLabel.text = "•"
        dotLabel.font = UIFont.systemFont(ofSize: 12)
        dotLabel.font = UIFont.boldSystemFont(ofSize: 16.0)
        dotLabel.backgroundColor = color
        dotLabel.textColor = UIColor.white
        contentView.addSubview(dotLabel)
        
        instructorLabel = UILabel()
        instructorLabel.translatesAutoresizingMaskIntoConstraints = false
        instructorLabel.textAlignment = .left
        instructorLabel.font = UIFont.systemFont(ofSize: 12)
        instructorLabel.textColor = UIColor.white
        instructorLabel.backgroundColor = color
        contentView.addSubview(instructorLabel)

        setupConstraints()
    }
    
    
    func setupConstraints() {
        NSLayoutConstraint.activate([
            codeLabel.topAnchor.constraint(equalTo: contentView.topAnchor, constant: 8),
            codeLabel.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 15),
            codeLabel.trailingAnchor.constraint(equalTo: contentView.trailingAnchor),
            codeLabel.heightAnchor.constraint(equalToConstant: 26)
        ])
        
        NSLayoutConstraint.activate([
            titleLabel.bottomAnchor.constraint(equalTo: codeLabel.bottomAnchor, constant: 15),
            titleLabel.leadingAnchor.constraint(equalTo: contentView.leadingAnchor, constant: 15),
            titleLabel.trailingAnchor.constraint(equalTo: codeLabel.trailingAnchor)
            
        ])
        NSLayoutConstraint.activate([
            dotLabel.topAnchor.constraint(equalTo: codeLabel.bottomAnchor),
            dotLabel.leadingAnchor.constraint(equalTo: titleLabel.trailingAnchor, constant: 8),
            dotLabel.heightAnchor.constraint(equalToConstant: 12)
        ])
        NSLayoutConstraint.activate([
            instructorLabel.topAnchor.constraint(equalTo: codeLabel.bottomAnchor, constant: 8),
            instructorLabel.leadingAnchor.constraint(equalTo: dotLabel.trailingAnchor, constant: 8)
            ])
    }
        func configure(for currclass: Course) {
            codeLabel.text = currclass.code
            titleLabel.text = currclass.name
            let color = colors[Int(arc4random_uniform(_:5))]
            backgroundColor = color
            codeLabel.backgroundColor = color
            titleLabel.backgroundColor = color
            dotLabel.backgroundColor = color
            instructorLabel.backgroundColor = color
    }
        required init?(coder: NSCoder) {
            fatalError("init(coder:) has not been implemented")
            }
        }
        
        
    


