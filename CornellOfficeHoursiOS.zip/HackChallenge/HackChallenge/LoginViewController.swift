//
//  LoginViewController.swift
//  HackChallenge
//
//  Created by Sophie Keller on 12/4/19.
//  Copyright © 2019 Sophie Keller. All rights reserved.
//

import UIKit

class LoginViewController: UIViewController {
    var userLabel: UILabel!
    var passLabel: UILabel!
    var userField: UITextField!
    var passField: UITextField!
    var doneButton: UIButton!
    var fontsize: Float = 25
    var delegate: LoginDelegate?
    var width: CGFloat = 150.0

    override func viewDidLoad() {
        super.viewDidLoad()

        title = "Login"
        view.backgroundColor = .white
        
        navigationController?.navigationBar.barTintColor = UIColor(red: 77/255.0,green: 128/255.0, blue: 228/255.0, alpha: 1.0)

        navigationController?.navigationBar.titleTextAttributes = [.foregroundColor: UIColor.white, .font: UIFont.boldSystemFont(ofSize: 25.0)]
        
        
        userLabel = UILabel()
        userLabel.text = "Username:"
        userLabel.textColor = .black
        userLabel.font = UIFont.boldSystemFont(ofSize: CGFloat(fontsize))
        userLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(userLabel)
        
        passLabel = UILabel()
        passLabel.text = "Password:"
        passLabel.textColor = .black
        passLabel.font = UIFont.boldSystemFont(ofSize: CGFloat(fontsize))
        passLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(passLabel)
        
        userField = UITextField()
        userField.textColor = .black
        userField.backgroundColor = .white
        userField.layer.borderColor = UIColor.lightGray.cgColor
        userField.layer.borderWidth = 1.0
        userField.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(userField)
        
        passField = UITextField()
        passField.textColor = .black
        passField.backgroundColor = .white
        passField.layer.borderColor = UIColor.lightGray.cgColor
        passField.layer.borderWidth = 1.0
        passField.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(passField)
        
        doneButton = UIButton()
        doneButton.translatesAutoresizingMaskIntoConstraints = false
        doneButton.contentEdgeInsets = UIEdgeInsets(top: 5, left: 10, bottom: 5, right: 10)
        doneButton.setTitle("Login", for: .normal)
        doneButton.titleLabel?.font = UIFont.boldSystemFont(ofSize: 25.0)
        doneButton.backgroundColor = UIColor(red: 77/255.0,green: 128/255.0, blue: 228/255.0, alpha: 1.0)
        doneButton.setTitleColor(.white, for: .normal)
          
        // When the button is pressed, dismiss this ModalViewController and change the button name
        doneButton.addTarget(self, action: #selector(Finish), for: .touchUpInside)
        view.addSubview(doneButton)
        
        setupConstraints()
    }
    func setupConstraints(){
    NSLayoutConstraint.activate([
        userLabel.topAnchor.constraint(equalTo: view.topAnchor, constant: 130),
        userLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor)
        
    ])
    NSLayoutConstraint.activate([
        userField.topAnchor.constraint(equalTo: userLabel.bottomAnchor, constant: 20),
        userField.centerXAnchor.constraint(equalTo: view.centerXAnchor),
        userField.widthAnchor.constraint(equalToConstant: width)
    ])
    NSLayoutConstraint.activate([
        passLabel.topAnchor.constraint(equalTo: userField.bottomAnchor, constant: 20),
        passLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor)
        
    ])
    NSLayoutConstraint.activate([
        passField.topAnchor.constraint(equalTo: passLabel.bottomAnchor, constant: 20),
        passField.centerXAnchor.constraint(equalTo: view.centerXAnchor),
        passField.widthAnchor.constraint(equalToConstant: width)
    ])
    NSLayoutConstraint.activate([
        doneButton.topAnchor.constraint(equalTo: passField.bottomAnchor, constant: 20),
        doneButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),
        doneButton.widthAnchor.constraint(equalToConstant: 210.0),
        doneButton.heightAnchor.constraint(equalToConstant: 60.0)
    ])

}
    @objc func Finish(){
        let dict = ["username": userField.text, "password": passField.text]
        NetworkManager.login(fromUser: dict as! [String : String]) { (data) in
            let tab = TabBarController(data: data)
            tab.data = data
            let controller = UINavigationController(rootViewController: tab)
            guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else {
                return
            }
            appDelegate.window?.rootViewController = controller
            appDelegate.window?.rootViewController?.navigationController?.isToolbarHidden = false
            appDelegate.window?.makeKeyAndVisible()
        }
            
        }
    }
    
