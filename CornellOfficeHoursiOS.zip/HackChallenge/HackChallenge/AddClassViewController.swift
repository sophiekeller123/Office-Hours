//
//  AddClassViewController.swift
//  HackChallenge
//
//  Created by Sophie Keller on 11/19/19.
//  Copyright © 2019 Sophie Keller. All rights reserved.
//

import UIKit

class AddClassViewController: UIViewController {
    var classLabel: UILabel!
    var deptTextField: UITextField!
    var numberTextField: UITextField!
    var addclassButton: UIButton!
    var fontsize: Float = 25
    var errorLabel: UILabel!
    var user: User!

    override func viewDidLoad() {
        super.viewDidLoad()

        title = "Add"
        view.backgroundColor = .white
        
        navigationController?.navigationBar.barTintColor = UIColor(red: 77/255.0,green: 128/255.0, blue: 228/255.0, alpha: 1.0)
        navigationController?.navigationBar.titleTextAttributes = [.foregroundColor: UIColor.white]

        
        classLabel = UILabel()
        classLabel.text = "Class Title:"
        classLabel.textColor = .black
        classLabel.font = UIFont.boldSystemFont(ofSize: CGFloat(fontsize))
        classLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(classLabel)
        
        deptTextField = UITextField()
        deptTextField.textColor = .black
        deptTextField.backgroundColor = .white
        deptTextField.layer.borderColor = UIColor.lightGray.cgColor
        deptTextField.layer.borderWidth = 1.0
        deptTextField.font = UIFont.systemFont(ofSize: CGFloat(fontsize))
        deptTextField.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(deptTextField)
        
        numberTextField = UITextField()
        numberTextField.textColor = .black
        numberTextField.backgroundColor = .white
        numberTextField.font = UIFont.systemFont(ofSize: CGFloat(fontsize))
        numberTextField.layer.borderColor = UIColor.lightGray.cgColor
        numberTextField.layer.borderWidth = 1.0
        numberTextField.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(numberTextField)
        
        addclassButton = UIButton()
        addclassButton.translatesAutoresizingMaskIntoConstraints = false
        addclassButton.contentEdgeInsets = UIEdgeInsets(top: 5, left: 10, bottom: 5, right: 10)
        addclassButton.setTitle("Add Class", for: .normal)
        addclassButton.titleLabel?.font = UIFont.boldSystemFont(ofSize: 25.0)
        addclassButton.backgroundColor = UIColor(red: 77/255.0,green: 128/255.0, blue: 228/255.0, alpha: 1.0)
        addclassButton.setTitleColor(.white, for: .normal)
        
        errorLabel = UILabel()
        errorLabel.textColor = .black
        errorLabel.text = ""
        errorLabel.font = UIFont.boldSystemFont(ofSize: CGFloat(fontsize))
        errorLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(errorLabel)
          
        // When the button is pressed, dismiss this ModalViewController and change the button name
        addclassButton.addTarget(self, action: #selector(showLabel), for: .touchUpInside)
        view.addSubview(addclassButton)
        
        setupConstraints()
    }
    func setupConstraints(){
    NSLayoutConstraint.activate([
        classLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 30),
        classLabel.topAnchor.constraint(equalTo: view.topAnchor, constant: 130),
    ])
    NSLayoutConstraint.activate([
        deptTextField.leadingAnchor.constraint(equalTo: view.trailingAnchor, constant: -250),
        deptTextField.widthAnchor.constraint(equalToConstant: 75.0),
        deptTextField.topAnchor.constraint(equalTo: classLabel.topAnchor),
        deptTextField.heightAnchor.constraint(equalTo: classLabel.heightAnchor)
    ])
    NSLayoutConstraint.activate([
        numberTextField.leadingAnchor.constraint(equalTo: deptTextField.trailingAnchor, constant: 8),
        numberTextField.topAnchor.constraint(equalTo: classLabel.topAnchor),
        numberTextField.heightAnchor.constraint(equalTo: classLabel.heightAnchor),
        numberTextField.widthAnchor.constraint(equalTo: deptTextField.widthAnchor)
    ])
    NSLayoutConstraint.activate([
        addclassButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),
        addclassButton.topAnchor.constraint(equalTo: numberTextField.bottomAnchor, constant: 30),
        addclassButton.widthAnchor.constraint(equalToConstant: 180.0),
        addclassButton.heightAnchor.constraint(equalToConstant: 60.0)
        ])
    NSLayoutConstraint.activate([
        errorLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
        errorLabel.topAnchor.constraint(equalTo: addclassButton.bottomAnchor, constant: 30)
    ])

}
    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.tabBarController?.navigationItem.title = "Add Class"
        navigationController?.navigationBar.titleTextAttributes = [.foregroundColor: UIColor.white, .font: UIFont.boldSystemFont(ofSize: 25.0)]
        self.tabBarController?.navigationController?.navigationBar.barTintColor = UIColor(red: 77/255.0,green: 128/255.0, blue: 228/255.0, alpha: 1.0)
    }
    func addClass(complete: @escaping (_ success: Bool) -> Void) {
        let name = deptTextField.text! + "+" + numberTextField.text!
        NetworkManager.getCoursefromCode(fromCode: name){ data, bool  in
            if bool{
                complete(true)
            }else{
                complete(false)}
            NetworkManager.addClass(fromId: data, fromUserID: self.user.id){ (data) in
                self.user = data
            }

    }
        
    }
    
    @objc func showLabel() {
        addClass { (success) -> Void in
            if success {
                self.errorLabel.textColor = UIColor(red: 77/255.0,green: 128/255.0, blue: 228/255.0, alpha: 1.0)
                self.errorLabel.text = "Class Added Successfully"
                self.deptTextField.text = ""
                self.numberTextField.text = ""
            } else {
                self.errorLabel.textColor = .red
                self.errorLabel.text = "Course Not Found"
            }
            
        }
    }
    
}
    
    

