//
//  AddViewController.swift
//  HackChallenge
//
//  Created by Sophie Keller on 11/17/19.
//  Copyright © 2019 Sophie Keller. All rights reserved.
//

import UIKit

class AddViewController: UIViewController {
    var classLabel: UILabel!
    var dateLabel: UILabel!
    var timeLabel: UILabel!
    var locationLabel: UILabel!
    var memosLabel: UILabel!
    var deptTextField: UITextField!
    var numberTextField: UITextField!
    var dateTextField: UITextField!
    var timeTextField: UITextField!
    var locationTextField: UITextField!
    var memosTextView: UITextView!
    var fontsize: Float = 18.0
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        title = "Add"
        view.backgroundColor = .white
        
        navigationController?.navigationBar.barTintColor = UIColor(red: 242.0/255.0, green: 148.0/255.0, blue: 140.0/255.0, alpha: 1.00)
        navigationController?.navigationBar.titleTextAttributes = [.foregroundColor: UIColor.white]
        
        
        view.backgroundColor = .white
        
        classLabel = UILabel()
        classLabel.text = "Class Title:"
        classLabel.textColor = .black
        classLabel.font = UIFont.boldSystemFont(ofSize: CGFloat(fontsize))
        classLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(classLabel)
        
        deptTextField = UITextField()
        deptTextField.textColor = .black
        deptTextField.backgroundColor = .white
        deptTextField.layer.borderColor = UIColor.lightGray.cgColor
        deptTextField.layer.borderWidth = 1.0
        deptTextField.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(deptTextField)
        
        numberTextField = UITextField()
        numberTextField.textColor = .black
        numberTextField.backgroundColor = .white
        numberTextField.layer.borderColor = UIColor.lightGray.cgColor
        numberTextField.layer.borderWidth = 1.0
        numberTextField.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(numberTextField)
        
        dateLabel = UILabel()
        dateLabel.text = "Date:"
        dateLabel.textColor = .black
        dateLabel.font = UIFont.boldSystemFont(ofSize: CGFloat(fontsize))
        dateLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(dateLabel)
        
        dateTextField = UITextField()
        dateTextField.textColor = .black
        dateTextField.backgroundColor = .white
        dateTextField.layer.borderColor = UIColor.lightGray.cgColor
        dateTextField.layer.borderWidth = 1.0
        dateTextField.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(dateTextField)
        
        timeLabel = UILabel()
        timeLabel.text = "Time:"
        timeLabel.textColor = .black
        timeLabel.font = UIFont.boldSystemFont(ofSize: CGFloat(fontsize))
        timeLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(timeLabel)
        
        timeTextField = UITextField()
        timeTextField.textColor = .black
        timeTextField.backgroundColor = .white
        timeTextField.layer.borderColor = UIColor.lightGray.cgColor
        timeTextField.layer.borderWidth = 1.0
        timeTextField.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(timeTextField)
        
        locationLabel = UILabel()
        locationLabel.text = "Location:"
        locationLabel.textColor = .black
        locationLabel.font = UIFont.boldSystemFont(ofSize: CGFloat(fontsize))
        locationLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(locationLabel)
        
        locationTextField = UITextField()
        locationTextField.textColor = .black
        locationTextField.backgroundColor = .white
        locationTextField.layer.borderColor = UIColor.lightGray.cgColor
        locationTextField.layer.borderWidth = 1.0
        locationTextField.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(locationTextField)
        
        memosLabel = UILabel()
        memosLabel.text = "Memos:"
        memosLabel.textColor = .black
        memosLabel.font = UIFont.boldSystemFont(ofSize: CGFloat(fontsize))
        memosLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(memosLabel)
        
        memosTextView = UITextView()
        memosTextView.textColor = .black
        memosTextView.backgroundColor = .white
        memosTextView.layer.borderColor = UIColor.lightGray.cgColor
        memosTextView.layer.borderWidth = 1.0
        memosTextView.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(memosTextView)

        setupConstraints()
    }
    func setupConstraints(){
        NSLayoutConstraint.activate([
            classLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 15),
            classLabel.topAnchor.constraint(equalTo: view.topAnchor, constant: 100),
        ])
        NSLayoutConstraint.activate([
            deptTextField.leadingAnchor.constraint(equalTo: view.trailingAnchor, constant: -260),
            deptTextField.widthAnchor.constraint(equalToConstant: 40.0),
            deptTextField.topAnchor.constraint(equalTo: classLabel.topAnchor),
            deptTextField.heightAnchor.constraint(equalTo: classLabel.heightAnchor)
        ])
        NSLayoutConstraint.activate([
            numberTextField.leadingAnchor.constraint(equalTo: deptTextField.trailingAnchor, constant: 8),
            numberTextField.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -100),
            numberTextField.topAnchor.constraint(equalTo: classLabel.topAnchor),
            numberTextField.heightAnchor.constraint(equalTo: classLabel.heightAnchor)
        ])
        NSLayoutConstraint.activate([
            dateLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 15),
            dateLabel.topAnchor.constraint(equalTo: classLabel.bottomAnchor, constant: 15)
        ])
        NSLayoutConstraint.activate([
            dateTextField.leadingAnchor.constraint(equalTo: deptTextField.leadingAnchor),
            dateTextField.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -15),
            dateTextField.topAnchor.constraint(equalTo: dateLabel.topAnchor),
            dateTextField.heightAnchor.constraint(equalTo: dateLabel.heightAnchor)
        ])
        NSLayoutConstraint.activate([
            timeLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 15),
            timeLabel.topAnchor.constraint(equalTo: dateLabel.bottomAnchor, constant: 15)
        ])
        NSLayoutConstraint.activate([
            timeTextField.leadingAnchor.constraint(equalTo: deptTextField.leadingAnchor),
            timeTextField.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -15),
            timeTextField.topAnchor.constraint(equalTo: timeLabel.topAnchor),
            timeTextField.heightAnchor.constraint(equalTo: timeLabel.heightAnchor)
        ])
        NSLayoutConstraint.activate([
            locationLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 15),
            locationLabel.topAnchor.constraint(equalTo: timeLabel.bottomAnchor, constant: 15)
        ])
        NSLayoutConstraint.activate([
            locationTextField.leadingAnchor.constraint(equalTo: deptTextField.leadingAnchor),
            locationTextField.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -15),
            locationTextField.topAnchor.constraint(equalTo: locationLabel.topAnchor),
            locationTextField.heightAnchor.constraint(equalTo: locationLabel.heightAnchor)
        ])
        NSLayoutConstraint.activate([
            memosLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 15),
            memosLabel.topAnchor.constraint(equalTo: locationLabel.bottomAnchor, constant: 15)
        ])
        NSLayoutConstraint.activate([
            memosTextView.leadingAnchor.constraint(equalTo: deptTextField.leadingAnchor),
            memosTextView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -15),
            memosTextView.topAnchor.constraint(equalTo: memosLabel.topAnchor),
            memosTextView.heightAnchor.constraint(equalToConstant: 300)
        ])
    }

}
