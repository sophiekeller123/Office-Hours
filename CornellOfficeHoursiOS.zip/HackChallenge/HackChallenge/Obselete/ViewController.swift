//
//  ViewController.swift
//  HackChallenge
//
//  Created by Sophie Keller on 11/17/19.
//  Copyright © 2019 Sophie Keller. All rights reserved.
//

import UIKit

//class ViewController: UIViewController {
//    var filterView: UICollectionView!
//    var calendarView: UICollectionView!
//    var days: [Day]!
//    var times: [String]!
//    var filters: [String]!
//
//    let dayCellReuseIdentifier = "dayCellReuseIdentifier"
//    let filterCellReuseIdentifier = "filterCellReuseIdentifier"
//    let padding: CGFloat = 10
//    let headerHeight: CGFloat = 140
//
//    override func viewDidLoad() {
//        super.viewDidLoad()
//
//        title = "My Office Hours"
//        view.backgroundColor = .white
//
//        navigationController?.navigationBar.barTintColor = UIColor(red: 242.0/255.0, green: 148.0/255.0, blue: 140.0/255.0, alpha: 1.00)
//        navigationController?.navigationBar.titleTextAttributes = [.foregroundColor: UIColor.white]
//
//        days = [Day(events: [""]), Day(events: ["Monday"]), Day(events: ["Tuesday"]), Day(events: ["Wednesday"]), Day(events: ["Thursday"]), Day(events: ["Friday"]), Day(events: ["Saturday"]), Day(events: ["Sunday"])]
//
//        times = ["10am", "11am", "12pm", "1pm", "2pm", "3pm"]
//        for time in times{
//            days.append(Day(events: [time]))
//            days.append(contentsOf: [Day(events: [""]), Day(events: [""]), Day(events: [""]), Day(events: [""]), Day(events: [""]), Day(events: [""]), Day(events: [""])])
//        }
//
//        let layout = UICollectionViewFlowLayout()
//        layout.scrollDirection = .vertical
//        layout.minimumLineSpacing = (1/3)*padding
//        layout.minimumInteritemSpacing = 0
//
//        calendarView = UICollectionView(frame: .zero, collectionViewLayout: layout)
//        calendarView.translatesAutoresizingMaskIntoConstraints = false
//        calendarView.backgroundColor = .white
//        calendarView.register(CalendarCollectionViewCell.self, forCellWithReuseIdentifier: dayCellReuseIdentifier)
//
//        calendarView.dataSource = self
//        calendarView.delegate = self
//
//        filters = ["CS 2110", "CS 2800", "INFO 1200", "MATH 2930"]
//
//        let filterlayout = UICollectionViewFlowLayout()
//        filterlayout.scrollDirection = .horizontal
//        filterlayout.minimumLineSpacing = padding
//        filterlayout.minimumInteritemSpacing = padding
//
//        filterView = UICollectionView(frame: .zero, collectionViewLayout: filterlayout)
//        filterView.translatesAutoresizingMaskIntoConstraints = false
//        filterView.backgroundColor = .white
//        filterView.register(FilterCollectionViewCell.self, forCellWithReuseIdentifier: filterCellReuseIdentifier)
//        filterView.dataSource = self
//        filterView.delegate = self
//
//        view.addSubview(filterView)
//        view.addSubview(calendarView)
//
//        setupConstraints()
//    }
//    func setupConstraints() {
//           NSLayoutConstraint.activate([
//               filterView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: padding),
//               filterView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: padding),
//               filterView.heightAnchor.constraint(equalToConstant: 50),
//               filterView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -padding)
//           ])
//           NSLayoutConstraint.activate([
//            calendarView.topAnchor.constraint(equalTo: filterView.bottomAnchor, constant: padding),
//               calendarView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: padding),
//               calendarView.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: -padding),
//               calendarView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -padding)
//           ])
//       }
//}
//extension ViewController: UICollectionViewDataSource {
//
//func numberOfSections(in collectionView: UICollectionView) -> Int {
//    return 1
//}
//
//func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
//    if collectionView == filterView{
//        return filters.count
//    }
//    return days.count
//}
//
//
//func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
//    if collectionView == filterView{
//        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: filterCellReuseIdentifier, for: indexPath) as! FilterCollectionViewCell
//        cell.configure(for: filters[indexPath.row])
//        return cell
//    }
//    let cell = collectionView.dequeueReusableCell(withReuseIdentifier: dayCellReuseIdentifier, for: indexPath) as! CalendarCollectionViewCell
//    cell.configure(for: days[indexPath.row])
//    return cell
//
//    }
//
//}
//
//extension ViewController: UICollectionViewDelegateFlowLayout {
//
//    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
//        if collectionView == filterView{
//            let label = UILabel()
//            label.text = filters[indexPath.row]
//            label.font = UIFont.boldSystemFont(ofSize: 16.0)
//            label.sizeToFit()
//            return CGSize(width: label.frame.width+20, height: label.frame.height+20)
//
//        }
//        // We want: | padding CELL padding CELL padding CELL padding |
//        let size = (collectionView.frame.width - 2 * padding) / 8.0
//        return CGSize(width: size, height: size)
//    }
//
//    @objc func pushAddViewController(){
//        let viewController = AddViewController()
//        navigationController?.pushViewController(viewController, animated: true)
//    }
//
//}
//
