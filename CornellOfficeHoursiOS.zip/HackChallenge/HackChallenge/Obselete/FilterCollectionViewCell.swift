//
//  FilterCollectionViewCell.swift
//  HackChallenge
//
//  Created by Sophie Keller on 11/17/19.
//  Copyright © 2019 Sophie Keller. All rights reserved.
//

import UIKit

class FilterCollectionViewCell: UICollectionViewCell {
    var filterLabel: UILabel!
    

    override init(frame: CGRect) {
        super.init(frame: frame)

        filterLabel = UILabel()
        filterLabel.translatesAutoresizingMaskIntoConstraints = false
        filterLabel.textAlignment = .center
        filterLabel.clipsToBounds = true
        filterLabel.layer.cornerRadius = 5
        filterLabel.backgroundColor = UIColor(red: 242.0/255.0, green: 148.0/255.0, blue: 140.0/255.0, alpha: 1.00)
        
        filterLabel.textColor = .white
        filterLabel.font = UIFont.boldSystemFont(ofSize: 16.0)
        addSubview(filterLabel)
        
        setupConstraints()
    }

    func setupConstraints() {
        NSLayoutConstraint.activate([
            filterLabel.topAnchor.constraint(equalTo: contentView.topAnchor),
            filterLabel.leadingAnchor.constraint(equalTo: contentView.leadingAnchor),
            filterLabel.trailingAnchor.constraint(equalTo: contentView.trailingAnchor),
            filterLabel.bottomAnchor.constraint(equalTo: contentView.bottomAnchor)
        ])
        
    }
    
    func configure(for filter: String) {
        filterLabel.text = filter
    }

    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

