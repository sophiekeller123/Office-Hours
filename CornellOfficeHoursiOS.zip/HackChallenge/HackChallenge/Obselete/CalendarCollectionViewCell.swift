//
//  CalendarCollectionViewCell.swift
//  HackChallenge
//
//  Created by Sophie Keller on 11/17/19.
//  Copyright © 2019 Sophie Keller. All rights reserved.
//

import UIKit

class CalendarCollectionViewCell: UICollectionViewCell {
    var dayLabel: UILabel!
    
        override init(frame: CGRect) {
            super.init(frame: frame)

            dayLabel = UILabel()
            dayLabel.translatesAutoresizingMaskIntoConstraints = false
            dayLabel.textAlignment = .center
            dayLabel.clipsToBounds = true
            dayLabel.backgroundColor = UIColor(red: 230.0/255.0, green: 230.0/255.0, blue: 230.0/255.0, alpha: 1.00)
            dayLabel.layer.borderColor =  UIColor.black.cgColor
            dayLabel.layer.borderWidth = 2.0
            
            dayLabel.textColor = .black
            dayLabel.font = UIFont.boldSystemFont(ofSize: 16.0)
            addSubview(dayLabel)
            
            setupConstraints()
        }

        func setupConstraints() {
            NSLayoutConstraint.activate([
                dayLabel.topAnchor.constraint(equalTo: contentView.topAnchor),
                dayLabel.leadingAnchor.constraint(equalTo: contentView.leadingAnchor),
                dayLabel.trailingAnchor.constraint(equalTo: contentView.trailingAnchor),
                dayLabel.bottomAnchor.constraint(equalTo: contentView.bottomAnchor)
            ])
            
        }
        
//        func configure(for day: Day) {
//            let events = day.events.joined(separator: ", ")
//            dayLabel.text = events
//        }

        required init?(coder: NSCoder) {
            fatalError("init(coder:) has not been implemented")
        }
    }

