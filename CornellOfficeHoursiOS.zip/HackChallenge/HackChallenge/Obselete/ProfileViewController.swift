//
//  ProfileViewController.swift
//  HackChallenge
//
//  Created by Sophie Keller on 11/18/19.
//  Copyright © 2019 Sophie Keller. All rights reserved.
//

import UIKit

class ProfileViewController: UIViewController {
    var profileLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        title = "Profile"
        view.backgroundColor = .white
        
        navigationController?.navigationBar.barTintColor = UIColor(red: 242.0/255.0, green: 148.0/255.0, blue: 140.0/255.0, alpha: 1.00)
        navigationController?.navigationBar.titleTextAttributes = [.foregroundColor: UIColor.white]
        
        view.backgroundColor = .white
        
        profileLabel = UILabel()
        profileLabel.text = "Class Title:"
        profileLabel.textColor = .black
        profileLabel.font = UIFont.boldSystemFont(ofSize: 16)
        profileLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(profileLabel)
        
        setupConstraints()
        // Do any additional setup after loading the view.
    }
    func setupConstraints(){
        NSLayoutConstraint.activate([
            profileLabel.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 15),
            profileLabel.topAnchor.constraint(equalTo: view.topAnchor, constant: 100),
               ])
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
