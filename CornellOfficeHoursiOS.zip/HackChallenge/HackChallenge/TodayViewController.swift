//
//  TodayViewController.swift
//  HackChallenge
//
//  Created by Sophie Keller on 11/18/19.
//  Copyright © 2019 Sophie Keller. All rights reserved.
//

import UIKit

protocol LoginDelegate: class{
    func setuserdata(to user: User)
//    func setlogin(to dict: [String: String])
    func setdone(to bool: Bool)
}

class TodayViewController: UIViewController {
    var hoursView: UICollectionView!
    var events: [Event] = []
    var user: User!
    var newuserinfo: [String:String] = [:]
    var logininfo: [String:String] = [:]
    var errorLabel: UILabel!
    var todaysevents: [Event] = []
    var day: String!
    var colors: [UIColor]!
    
    let eventReuseIdentifier = "eventreuseidentifier"
    let padding: CGFloat = 8

    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        
        
        title = "Today's Schedule"
        view.backgroundColor = .white
        
        navigationController?.navigationBar.barTintColor = UIColor(red: 77/255.0,green: 128/255.0, blue: 228/255.0, alpha: 1.0)

        navigationController?.navigationBar.titleTextAttributes = [.foregroundColor: UIColor.white]
        
        
        
        
        let layout = UICollectionViewFlowLayout()
        layout.scrollDirection = .vertical
        layout.minimumLineSpacing = padding
        layout.minimumInteritemSpacing = padding
        
        day = getWeekday()
        
        todaysevents = filter(events: self.events)
        
        hoursView = UICollectionView(frame: .zero, collectionViewLayout: layout)
        hoursView.translatesAutoresizingMaskIntoConstraints = false
        hoursView.backgroundColor = .white
        hoursView.register(HoursCollectionViewCell.self, forCellWithReuseIdentifier: eventReuseIdentifier)
        view.addSubview(hoursView)
        hoursView.dataSource = self
        hoursView.delegate = self
        
        errorLabel = UILabel()
        errorLabel.textColor = UIColor(red: 77/255.0,green: 128/255.0, blue: 228/255.0, alpha: 1.0)
        errorLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(errorLabel)
        if self.events.isEmpty{
                   errorLabel.text = "No Office Hours Today"
               }else{
                   errorLabel.text = ""
               }
        
        NetworkManager.getCourses(fromId: self.user.id) { (data) in
            self.user = data
            self.hoursView.reloadData()
        }
        
        
        
        setupConstraints()
    }
    func getWeekday() -> String {
        let today = Date()
        let weekday = Calendar.current.component(.weekday, from: today)
        let dictionary = [1:"Sunday", 2: "Monday", 3: "Tuesday", 4: "Wednesday", 5: "Thursday", 6: "Friday", 7: "Saturday"]
        return dictionary[2]!
        
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        errorLabel.text = ""
        NetworkManager.getCourses(fromId: self.user.id) { (data) in
            self.user = data
            self.events = []
            var dicttosort: [Double:[Event]] = [:]
            let courses = self.user.courses
            for course in courses{
                for instructor in course.instructors{
                    for officehour in instructor.officehours{
                        if dicttosort[Double(officehour.time[0].start_hours) + (Double(officehour.time[0].start_minutes)/60.0)] != nil{
                            dicttosort[Double(officehour.time[0].start_hours) + (Double(officehour.time[0].start_minutes)/60.0)]!.append(Event(start: [officehour.time[0].start_hours, officehour.time[0].start_minutes], end: [officehour.time[0].end_hours, officehour.time[0].end_minutes], ta: instructor.name, location: officehour.place + " " + String(officehour.room), classs: course.code, day: officehour.day))
                        }else{
                        dicttosort[Double(officehour.time[0].start_hours) + (Double(officehour.time[0].start_minutes)/60.0)] = [Event(start: [officehour.time[0].start_hours, officehour.time[0].start_minutes], end: [officehour.time[0].end_hours, officehour.time[0].end_minutes], ta: instructor.name, location: officehour.place + " " + String(officehour.room), classs: course.code, day: officehour.day)]
                    }
                }
                }
            }
        let keys = Array(dicttosort.keys)
        let sortedkeys = keys.sorted()
        for key in sortedkeys{
            for event in dicttosort[key]!{
                self.events.append(event)
            }
        }
            self.todaysevents = self.filter(events: self.events)
        if self.todaysevents.isEmpty{
            self.errorLabel.text = "No Office Hours Today"
        }else{
            self.errorLabel.text = ""
        }
        self.hoursView.reloadData()
    }
        
        self.tabBarController?.navigationItem.title = "Office Hours Today"
        self.tabBarController?.navigationController?.navigationBar.barTintColor = UIColor(red: 77/255.0,green: 128/255.0, blue: 228/255.0, alpha: 1.0)

        self.tabBarController?.navigationController?.navigationBar.titleTextAttributes = [NSAttributedString.Key.foregroundColor: UIColor.white]
        navigationController?.navigationBar.titleTextAttributes = [.foregroundColor: UIColor.white, .font: UIFont.boldSystemFont(ofSize: 25.0)]
    }
    
    func filter(events: [Event]) -> [Event]{
        var filtered: [Event] = []
        for event in events{
            if event.day == self.day{
                filtered.append(event)
            }
        }
        return filtered
    }
    
    func setupConstraints(){
        NSLayoutConstraint.activate([
            errorLabel.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 5*padding),
            errorLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
        ])
        NSLayoutConstraint.activate([
            hoursView.topAnchor.constraint(equalTo: errorLabel.bottomAnchor, constant: padding),
            hoursView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 2*padding),
            hoursView.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: padding),
            hoursView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -2*padding)
        ])
    }

}
extension TodayViewController: UICollectionViewDataSource {
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return todaysevents.count
    }
    
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: eventReuseIdentifier, for: indexPath) as! HoursCollectionViewCell
            cell.configure(for: todaysevents[indexPath.row])
            return cell
    }
}
extension TodayViewController: UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: collectionView.frame.width, height: 60)
    }
    
}

