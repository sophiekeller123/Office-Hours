//
//  CreateAccountViewController.swift
//  HackChallenge
//
//  Created by Sophie Keller on 12/4/19.
//  Copyright © 2019 Sophie Keller. All rights reserved.
//

import UIKit

class CreateAccountViewController: UIViewController {
    var nameLabel: UILabel!
    var userLabel: UILabel!
    var passLabel: UILabel!
    var nameField: UITextField!
    var userField: UITextField!
    var passField: UITextField!
    var doneButton: UIButton!
    var fontsize: Float = 25
    var delegate: LoginDelegate?
    var data: User!
    var width: CGFloat = 150.0

    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Create Account"
        view.backgroundColor = .white
        
        navigationController?.navigationBar.barTintColor = UIColor(red: 77/255.0,green: 128/255.0, blue: 228/255.0, alpha: 1.0)

        navigationController?.navigationBar.titleTextAttributes = [.foregroundColor: UIColor.white, .font: UIFont.boldSystemFont(ofSize: 25.0)]

        
        nameLabel = UILabel()
        nameLabel.text = "Name:"
        nameLabel.textColor = .black
        nameLabel.font = UIFont.boldSystemFont(ofSize: CGFloat(fontsize))
        nameLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(nameLabel)
        
        userLabel = UILabel()
        userLabel.text = "Username:"
        userLabel.textColor = .black
        userLabel.font = UIFont.boldSystemFont(ofSize: CGFloat(fontsize))
        userLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(userLabel)
        
        passLabel = UILabel()
        passLabel.text = "Password:"
        passLabel.textColor = .black
        passLabel.font = UIFont.boldSystemFont(ofSize: CGFloat(fontsize))
        passLabel.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(passLabel)
        
    
        nameField = UITextField()
        
        nameField.textColor = .black
        nameField.backgroundColor = .white
        nameField.layer.borderColor = UIColor.lightGray.cgColor
        nameField.layer.borderWidth = 1.0
        nameField.translatesAutoresizingMaskIntoConstraints = false
        nameField.textColor = .black
        nameField.font = UIFont.systemFont(ofSize: CGFloat(fontsize))
        view.addSubview(nameField)
        
        userField = UITextField()
        userField.textColor = .black
        userField.backgroundColor = .white
        userField.layer.borderColor = UIColor.lightGray.cgColor
        userField.layer.borderWidth = 1.0
        userField.font = UIFont.systemFont(ofSize: CGFloat(fontsize))
        userField.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(userField)
        
        passField = UITextField()
        passField.textColor = .black
        passField.backgroundColor = .white
        passField.layer.borderColor = UIColor.lightGray.cgColor
        passField.layer.borderWidth = 1.0
        passField.font = UIFont.systemFont(ofSize: CGFloat(fontsize))
        passField.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(passField)
        
        doneButton = UIButton()
        doneButton.translatesAutoresizingMaskIntoConstraints = false
        doneButton.contentEdgeInsets = UIEdgeInsets(top: 5, left: 10, bottom: 5, right: 10)
        doneButton.setTitle("Create Account", for: .normal)
        doneButton.titleLabel?.font = UIFont.boldSystemFont(ofSize: 25.0)
        doneButton.backgroundColor = UIColor(red: 77/255.0,green: 128/255.0, blue: 228/255.0, alpha: 1.0)
        doneButton.setTitleColor(.white, for: .normal)
        
          
        // When the button is pressed, dismiss this ModalViewController and change the button name
        doneButton.addTarget(self, action: #selector(Finish), for: .touchUpInside)
        view.addSubview(doneButton)
        
        setupConstraints()
    }
    func setupConstraints(){
    NSLayoutConstraint.activate([
        nameLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
        nameLabel.topAnchor.constraint(equalTo: view.topAnchor, constant: 130),
    ])
    NSLayoutConstraint.activate([
        nameField.topAnchor.constraint(equalTo: nameLabel.bottomAnchor, constant: 20),
        nameField.centerXAnchor.constraint(equalTo: view.centerXAnchor),
        nameField.widthAnchor.constraint(equalToConstant: width)
    ])
    NSLayoutConstraint.activate([
        userLabel.topAnchor.constraint(equalTo: nameField.bottomAnchor, constant: 20),
        userLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
    ])
    NSLayoutConstraint.activate([
        userField.topAnchor.constraint(equalTo: userLabel.bottomAnchor, constant: 20),
        userField.centerXAnchor.constraint(equalTo: view.centerXAnchor),
        userField.widthAnchor.constraint(equalToConstant: width)
    ])
    NSLayoutConstraint.activate([
        passLabel.topAnchor.constraint(equalTo: userField.bottomAnchor, constant: 20),
        passLabel.centerXAnchor.constraint(equalTo: view.centerXAnchor),
    ])
    NSLayoutConstraint.activate([
        passField.topAnchor.constraint(equalTo: passLabel.bottomAnchor, constant: 20),
        passField.centerXAnchor.constraint(equalTo: view.centerXAnchor),
        passField.widthAnchor.constraint(equalToConstant: width)
    ])
    NSLayoutConstraint.activate([
        doneButton.topAnchor.constraint(equalTo: passField.bottomAnchor, constant: 40),
        doneButton.centerXAnchor.constraint(equalTo: view.centerXAnchor),
        doneButton.widthAnchor.constraint(equalToConstant: 210.0),
        doneButton.heightAnchor.constraint(equalToConstant: 60.0)
        
    ])

}
    @objc func Finish(){
        let dict = ["name": nameField.text, "username": userField.text, "password": passField.text]
        NetworkManager.makeacct(fromUser: dict as! [String : String]) { (data) in
            self.data = data
            let tab = TabBarController(data: data)
            tab.data = self.data
            let controller = UINavigationController(rootViewController: tab)
            guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else {
                return
            }
            appDelegate.window?.rootViewController = controller
            appDelegate.window?.rootViewController?.navigationController?.isToolbarHidden = false
            appDelegate.window?.makeKeyAndVisible()
        }
        
    }
    
}
