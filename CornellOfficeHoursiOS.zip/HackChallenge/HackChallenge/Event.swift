//
//  Event.swift
//  HackChallenge
//
//  Created by Sophie Keller on 11/18/19.
//  Copyright © 2019 Sophie Keller. All rights reserved.
//

import Foundation

class Event: Codable {
    var starttime: [Int]!
    var endtime: [Int]!
    var ta: String!
    var location: String!
    var classs: String
    var day: String!
    
    init(start: [Int], end: [Int], ta: String, location: String, classs: String, day: String) {
        self.starttime = start
        self.endtime = end
        self.ta = ta
        self.location = location
        self.classs = classs
        self.day = day
        }
    
    }



