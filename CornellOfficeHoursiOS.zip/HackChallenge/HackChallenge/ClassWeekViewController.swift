//
//  ClassWeekViewController.swift
//  HackChallenge
//
//  Created by Sophie Keller on 11/20/19.
//  Copyright © 2019 Sophie Keller. All rights reserved.
//
//
import UIKit

class ClassWeekViewController: UIViewController {
    var hoursView: UICollectionView!
    var events: [Int: [Event]] = [:]
    var sortevents: [Int: [Event]] = [:]
    var headerView: DayHeaderView!
    var classs: [String]! = []
    let eventReuseIdentifier = "eventreuseidentifier"
    let padding: CGFloat = 8
    var selectedclass: Course!
    var user: User!

    override func viewDidLoad() {
            super.viewDidLoad()
        
        
            title = "This Week's Schedule for \(selectedclass.code)"
            view.backgroundColor = .white

            navigationController?.navigationBar.barTintColor = UIColor(red: 77/255.0,green: 128/255.0, blue: 228/255.0, alpha: 1.0)
            navigationController?.navigationBar.titleTextAttributes = [.foregroundColor: UIColor.white, .font: UIFont.boldSystemFont(ofSize: 18.0)]

            
            let course = self.selectedclass
            for instructor in course!.instructors{
                    for officehour in instructor.officehours{
                        let event = Event(start: [officehour.time[0].start_hours, officehour.time[0].start_minutes], end: [officehour.time[0].end_hours, officehour.time[0].end_minutes], ta: instructor.name, location: officehour.place + " " + String(officehour.room), classs: course!.code, day: officehour.day)
                        let helper = ["Sunday": 0, "Monday":1, "Tuesday": 2, "Wednesday": 3, "Thursday": 4, "Friday": 5, "Saturday": 6]
                     if self.events[helper[officehour.day]!] == nil {
                         self.events[helper[officehour.day]!] = [event]
                        }
                        else{
                         self.events[helper[officehour.day]!]!.append(event)
                        }
                    }
                }
            
            sortevents = sortevents(events: events)

            let layout = UICollectionViewFlowLayout()
            layout.scrollDirection = .vertical
            layout.minimumLineSpacing = padding
            layout.minimumInteritemSpacing = padding
            layout.headerReferenceSize = CGSize(width: view.frame.width,height: 60)
            
            headerView = DayHeaderView(frame: CGRect(x: 0
                , y: 0, width: view.frame.width, height: 60))

            hoursView = UICollectionView(frame: .zero, collectionViewLayout: layout)
            hoursView.translatesAutoresizingMaskIntoConstraints = false
            hoursView.backgroundColor = .white
            hoursView.dataSource = self
            hoursView.delegate = self
        
            hoursView.register(HoursCollectionViewCell.self, forCellWithReuseIdentifier: eventReuseIdentifier)
            hoursView.register(DayHeaderView.self, forSupplementaryViewOfKind: UICollectionView.elementKindSectionHeader, withReuseIdentifier: "headerCell")
            view.addSubview(hoursView)

            setupConstraints()
        }
        func setupConstraints(){
            NSLayoutConstraint.activate([
                hoursView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: padding),
                hoursView.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 2*padding),
                hoursView.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: padding),
                hoursView.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -2*padding)
            ])
        }
    func sortevents(events: [Int: [Event]]) -> [Int: [Event]]{
        var newevents: [Int:[Event]] = [:]
        for date in events{
            for event in events[date.key]!{
                if event.classs == selectedclass.name {
                    if newevents[date.key] == nil {
                        newevents[date.key] = [event]
                    }
                    else{
                        newevents[date.key]!.append(event)
                    }
            }
        }
        }
        return newevents

}
    
}

extension ClassWeekViewController: UICollectionViewDataSource {
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return events.count
    }
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        let dates = Array(events.keys)
        let newdates = dates.sorted()
        
        return events[newdates[section]]!.count

        }
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let dates = Array(events.keys)
        let newdates = dates.sorted()
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: eventReuseIdentifier, for: indexPath) as! HoursCollectionViewCell
        cell.configure(for: events[newdates[indexPath.section]]![indexPath.row])
        return cell
    }
    func collectionView(_ collectionView: UICollectionView, viewForSupplementaryElementOfKind kind: String, at indexPath: IndexPath) -> UICollectionReusableView {
        let headerView = collectionView.dequeueReusableSupplementaryView(ofKind: UICollectionView.elementKindSectionHeader, withReuseIdentifier: "headerCell", for: indexPath) as! DayHeaderView
        let dates = Array(events.keys)
        let newdates = dates.sorted()
        let helper: [Int:String] = [0: "Sunday", 1: "Monday", 2: "Tuesday", 3:"Wednesday", 4: "Thursday", 5:"Friday", 6: "Saturday"]
        let text = helper[newdates[indexPath.section]]
        headerView.label.text = text
        headerView.label.textColor = UIColor(red: 77/255.0,green: 128/255.0, blue: 228/255.0, alpha: 1.0)
        return headerView
    }
    
    func remove0(date: String) -> String{
        let index = date.index(date.startIndex, offsetBy: 1)
        let new = date[..<index]
        if new == "0"{
            let index = date.index(date.endIndex, offsetBy: -1)
            let new = date.suffix(from: index)
            return String(new)
        }
        return date
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.tabBarController?.navigationItem.title = "This Week's Schedule for \(selectedclass.code)"
        self.tabBarController?.navigationController?.navigationBar.barTintColor = .lightGray
        self.tabBarController?.navigationController?.navigationBar.titleTextAttributes = [NSAttributedString.Key.foregroundColor: UIColor.white]
    }
}
extension ClassWeekViewController: UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: collectionView.frame.width, height: 60)
    }
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, referenceSizeForHeaderInSection section: Int) -> CGSize {
            return CGSize(width: collectionView.frame.width, height: 60)
        }

    }

