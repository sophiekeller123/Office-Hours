//
//  DayHeaderView.swift
//  HackChallenge
//
//  Created by Sophie Keller on 11/25/19.
//  Copyright © 2019 Sophie Keller. All rights reserved.
//

import UIKit

class DayHeaderView: UICollectionReusableView {
        var label: UILabel!
        
        override init(frame: CGRect) {
            super.init(frame: frame)
            backgroundColor = .white
            
            label = UILabel()
            label.translatesAutoresizingMaskIntoConstraints = false
            label.text = "Day"
            label.textColor = .black
            label.textAlignment = .center
            addSubview(label)
            
            setupConstraints()
        }
        
        required init?(coder: NSCoder) {
            fatalError("init(coder:) has not been implemented")
        }
        
        func setupConstraints() {
            NSLayoutConstraint.activate([
                label.leadingAnchor.constraint(equalTo: self.leadingAnchor),
                label.topAnchor.constraint(equalTo: self.topAnchor),
                label.trailingAnchor.constraint(equalTo: self.trailingAnchor),
                label.bottomAnchor.constraint(equalTo: self.bottomAnchor)
            ])
        }
}
